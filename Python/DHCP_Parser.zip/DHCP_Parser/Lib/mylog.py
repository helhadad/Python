"""
Script  : log_02.py
Author  : Hesham Elhadad
ID      : L00177542
Date    : 04-Nov-22
Purpose : This script demonstrates

Tested  : Python 3.10 on Windows 10 Pro
Rev     : 0
IDE     : PyCharm CE ver 2022

"""
import logging
import os
import os.path as op
import pathlib as pl
# important note is to rest the root logger to enable handlers to work on levels lower than warning
logging.root.setLevel(logging.NOTSET)
script_path = pl.Path(__file__)
log_path = (script_path / "../../Logs").resolve()

# Generating full path to the log file
log_file_name = op.join(log_path, "App_log.txt")


# configure two handlers, one for console and another for file
con_handler = logging.StreamHandler()
file_handler = logging.FileHandler(log_file_name)

con_handler.setLevel(logging.INFO)
file_handler.setLevel(logging.DEBUG)
# configure Formatters
con_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

con_handler.setFormatter(con_format)
file_handler.setFormatter(file_format)
# Adding the handlers to the logger instance


# uncomment the following lines to test logger and handler if the module run as main

# if __name__ == '__main__':
#     logger = logging.getLogger(__name__)  # it is recommended to use the __name__ as name of the logger
#     logger.addHandler(con_handler)
#     logger.addHandler(file_handler)
#     logger.debug("This is a debug message")
#     logger.info("This is an information message")
#     # logger.warning("This is a warning message")
#     logger.error("An Error occurred ")
