"""
Script  : app_functions.py
By      : Hesham Elhadad
ID      : L00177542
Date    : 30-Oct-22
Purpose : This script is used as common source of functions, constants, etc. of the
            solution of assignment-01
Tested  : Python 3.10 on Windows 10
Rev     : 0
IDE     : PyCharm CE ver 2022
"""
from Lib.mylog import file_handler
import os.path as op
import logging

# import string

# define a logger for this module
logger = logging.getLogger(__name__)
logger.addHandler(file_handler)


# The following function takes message to display for the user and return an input file path
def get_path_input(message) -> str:
    while True:
        try:
            inp_str = input(message)
            if op.isfile(inp_str):
                return inp_str
                break
            else:
                raise FileNotFoundError
        except FileNotFoundError:
            print(inp_str, "-is not suitable, please try again")
            logger.error("Wrong data entered = %s", inp_str)


# The following function takes message to display for the user and return an output dir path
def get_path_output(message) -> str:
    while True:
        try:
            inp_str = input(message)
            if op.isdir(inp_str):
                return inp_str
                break
            else:
                raise FileNotFoundError
        except FileNotFoundError:
            print(inp_str, "-is not suitable, please try again")
            logger.error("Wrong data entered = %s", inp_str)


# The following function will receive 2 argument (string and integer for a position in the string)
def get_substring(input_string, pos_in_string) -> str:
    word_list = input_string.split(' ')
    if pos_in_string <= len(word_list):
        return word_list[pos_in_string]
    else:
        return ""
