"""
Script  : pylint2.py
Author  : Hesham Elhadad
ID      : L00177542
Date    : 20-Oct-22
Purpose : This script demonstrates a solution to the exercises of walkthrough_09
          The implemented changes will yield a mark of 10/10 after running pylint

Tested  : Python 3.10 on Windows 10 Pro
Rev     : 0
IDE     : PyCharm CE ver 2022

"""

A=1
B=2
B=3
C="Hesham"

print(A+B)
print(A+B)
print(str(A)+C)
